@extends('layouts.page')

@section('title', 'Resume')
@section('content')
<div class="space-10"></div>
<div class="row">
    <div class="col-sm-12 center">
    	<resume-component></resume-component>
    </div>
</div>
@endsection