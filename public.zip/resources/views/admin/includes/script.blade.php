<script src="{{ asset('js/app.js') }}" ></script>
<script src="{{ asset('js/admin-custom.js') }}" ></script>
<script src="{{ asset('plugins/medium-editor/medium-editor.min.js') }}" ></script>