<ul class="social-share {{$type}}">
	<li>
		<a class="social" href="http://www.facebook.com/sharer.php?u={{$url}}" title="Share on Facebook">
			<i class="fa fa-facebook"></i>
		</a>
	</li>
	<li>
		<a href="https://twitter.com/intent/tweet?text={{$title}}&amp;url={{$url}}" title="Share on Twitter">
			<i class="fa fa-twitter"></i>
		</a>
	</li>
	<li>
		<a href="http://www.linkedin.com/shareArticle?mini=true&amp;url={{$url}}&amp;title={{$title}}" title="Share on Linkedin">
			<i class="fa fa-linkedin"></i>
		</a>
	</li>
    <li>
    	<a href="https://wa.me/?text={{$url}}" title="Share on Whatsapp">
    		<i class="fa fa-whatsapp"></i>
    	</a>
    </li> 
</ul>