<div class="app-sidebar colored">
    <div class="sidebar-header">
        <a class="header-brand" href="<?php echo e(route('admin')); ?>">
            <div class="logo-img">
               <img height="40" src="<?php echo e(asset('images/logo.png')); ?>" class="header-brand-img" alt="lavalite"> 
            </div>
            <span class="text"></span>
        </a>
    </div>

    <?php
        $segment1 = request()->segment(2);
    ?>
    
    <div class="sidebar-content">
        <div class="nav-container">
            <nav id="main-menu-navigation" class="navigation-main">
                <div class="nav-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('dashboard')); ?>"><i class="fa fa-home"></i> <span>Dashboard</span></a>
                </div>
                <div class="nav-item <?php echo e(($segment1 == '' || $segment1 == ''||$segment1 == '') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="fa fa-newspaper-o"></i><span>Post</span></a>
                    <div class="submenu-content">
                        <a href="<?php echo e(url('')); ?>" class="menu-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">All Posts</a>
                        <a href="<?php echo e(url('')); ?>" class="menu-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">Add New</a>
                        <a href="<?php echo e(url('')); ?>" class="menu-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">Categories</a>
                        <a href="<?php echo e(url('')); ?>" class="menu-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">Tags</a>
                    </div>
                </div>
                <div class="nav-item <?php echo e(($segment1 == '' || $segment1 == ''||$segment1 == '') ? 'active open' : ''); ?> has-sub">
                    <a href="#"><i class="fa fa-folder-o"></i><span>Portfolio</span></a>
                    <div class="submenu-content">
                        <a href="<?php echo e(url('admin/portfolio')); ?>" class="menu-item <?php echo e(($segment1 == 'portfolio') ? 'active' : ''); ?>">All Portfolio</a>
                        <a href="<?php echo e(url('')); ?>" class="menu-item <?php echo e(($segment1 == '') ? 'active' : ''); ?>">Add Item</a>
                        <a href="<?php echo e(url('technologies')); ?>" class="menu-item <?php echo e(($segment1 == 'technologies') ? 'active' : ''); ?>">Technologies</a>
                    </div>
                </div>
                <div class="nav-item <?php echo e(($segment1 == 'settings') ? 'active' : ''); ?>">
                    <a href="{{}}"><i class="fa fa-cog"></i><span>Settings</span></a>
                </div>
            </nav>
        </div>
    </div>
</div><?php /**PATH /home/rakibhstu/public_html/resources/views/admin/includes/sidebar.blade.php ENDPATH**/ ?>