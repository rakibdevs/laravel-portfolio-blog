

<?php $__env->startSection('title', $portfolio->title); ?>
<?php $__env->startPush('css'); ?>
    <meta property="og:url"                content="<?php echo e(Request::url()); ?>" />
    <meta property="og:type"               content="Portfolio" />
    <meta property="og:title"              content="<?php echo e($portfolio->title); ?>" />
    <meta property="og:description"        content="How much does culture influence creative thinking?" />
    <meta property="og:image"              content="<?php echo e(asset('images/demo.jpg')); ?>">

    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="@nytimesbits" />
    <meta name="twitter:creator" content="@rakibhstu" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="space-10"></div>
<div class="row">
    <div class="col-sm-12 center">
        <h6>
            <p><i class="fa fa-home"></i> Portfolio / <?php echo e($portfolio->category['name']); ?> / <?php echo e($portfolio->title); ?></p>

            <h2><strong><?php echo e($portfolio->title); ?></strong></h2>
            <!-- fetch github insights from github url -->
            <?php if($portfolio->github_url != null): ?>
            <div class="github-insights">
                <a class="github-button" href="<?php echo e($portfolio->github_url); ?>/archive/master.zip" aria-label="Download from GitHub">Download</a>
                <a class="github-button" href="<?php echo e($portfolio->github_url); ?>/subscription" data-icon="octicon-eye" data-show-count="true" aria-label="Watch on GitHub">Watch</a>           

                <a class="github-button" href="<?php echo e($portfolio->github_url); ?>" data-icon="octicon-star" data-show-count="true" aria-label="Star on GitHub">Star</a>
                <a class="github-button" href="<?php echo e($portfolio->github_url); ?>/fork" data-icon="octicon-repo-forked" data-show-count="true" aria-label="Fork from GitHub">Fork</a>
                <a class="github-button" href="<?php echo e($portfolio->github_url); ?>/issues" data-icon="octicon-issue-opened" data-show-count="true" aria-label="Issue on GitHub">Issue</a>

            </div>
            <?php endif; ?>

        </h6>
        
    </div>
</div>
<hr>
<div class="row">
    <div class="col-sm-7">
        <?php if(count($portfolio->image)>0): ?>
            <slider-component :slides = "<?php echo e($portfolio->image); ?>" :features ="<?php echo e($portfolio); ?>" ></slider-component>
        <?php else: ?>
        	<img class="portfolio-feature" src="<?php echo e(asset($portfolio->feature_image)); ?>" onError="this.onerror=null;this.src='<?php echo e(asset('images/demo.jpg')); ?>';">
        <?php endif; ?>
        
    </div>
    <div class="col-sm-5">
        <strong>Technologies:</strong>
        <ul class="portfolio-tech">
            <?php $__currentLoopData = $portfolio->technology; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($tech->technology['name']); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <!-- check if duration exist -->
        <?php if($portfolio->start_at != null): ?>
        <p class="project-duration"><strong>Duration:</strong> <?php echo e($portfolio->start_at); ?>-<?php echo e($portfolio->end_at); ?></p>
        <?php endif; ?>
        <!-- check if client info exist -->
        <?php if($portfolio->client != null): ?>
        <p class="client"><strong>Client: </strong> <?php echo e($portfolio->client); ?></p>
        <?php endif; ?>
        <!-- check if project description exist -->
        <?php if($portfolio->description != null): ?>
        <strong>Description:</strong>
        <div class="portfolio-details">
            <?php echo $portfolio->description; ?>

        </div>
        <?php endif; ?>
        <div class="space-10"></div>
        <!-- check if demo url exist -->
        <?php if($portfolio->demo != null): ?>
        <div class="center"> 
            <a href="<?php echo e($portfolio->demo); ?>" class="btn btn-theme">View Demo</a>
        </div>
        <?php endif; ?>
        
    </div>     
</div>
</div>   
    <?php $__env->startPush('script'); ?>
        <script async defer src="https://buttons.github.io/buttons.js"></script>
       
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/portfolio-single.blade.php ENDPATH**/ ?>