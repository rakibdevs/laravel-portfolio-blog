

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-sm-12">
            Total Portfolio: <?php echo e($portfolios->total()); ?>

        </div>
        <div class="col-sm-12">
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="portfolio-item">
                <div class="p-image">
                    <img height="60" src="<?php echo e(url($portfolio->feature_image)); ?>">
                </div>
                <div class="p-title p-5"><?php echo e($portfolio->title); ?></div>
                <div class="p-category p-5"><?php echo e($portfolio->category['name']); ?></div>
                <div class="p-tech p-5">php wordpress jquery laravel</div>
                <div class="p-excerpt p-5"> <?php echo e(Str::limit($portfolio->description, $limit = 100, $end = '...')); ?></div>
                <div class="p-button p-5">
                    <a href="/portfolio/edit/<?php echo e($portfolio->id); ?>">
                        <i class="fa fa-pencil text-green p-5 mlr-5"></i>
                    </a>
                    <a href="/portfolio/delete/<?php echo e($portfolio->id); ?>">
                        <i class="fa fa-trash text-red p-5 mlr-5"></i>
                    </a>                  
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php echo $portfolios->render(); ?>

        </div> 
    </div>
</div>
<?php $__env->startPush('script'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rakibhstu/public_html/resources/views/admin/portfolios.blade.php ENDPATH**/ ?>