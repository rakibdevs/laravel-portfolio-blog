

<?php $__env->startSection('title', 'Resume'); ?>
<?php $__env->startSection('content'); ?>
<div class="space-10"></div>
<div class="row">
    <div class="col-sm-12 center">
    	<resume-component></resume-component>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/resume.blade.php ENDPATH**/ ?>