<?php
	$segment = request()->segment(1);
?>
<header>
	<div class="main-container">		
		<div class="row">
			<div class="col-sm-4 author-logo">
				<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
				<span class="mobile-humberger" onclick="openNav()">&#9776;</span>
			</div> 
			<div class="col-sm-8">
				<div id="main-menu" class="main-menu">
					<a href="javascript:void(0)" class="menu-close" onclick="closeNav()">&times;</a>
					<li ><a class="<?php echo e(($segment == '') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>" alt="HOME">HOME</a></li>
					<li ><a class="<?php echo e(($segment == 'portfolio') ? 'active' : ''); ?>" href="<?php echo e(url('portfolio')); ?>" alt="PORTFOLIO">PORTFOLIO</a></li>
					<li ><a class="<?php echo e(($segment == 'my-resume') ? 'active' : ''); ?>" href="<?php echo e(url('my-resume')); ?>" alt="RESUME">RESUME</a></li>
					<li ><a class="<?php echo e(($segment == 'blog') ? 'active' : ''); ?>" alt="BLOG">BLOG</a></li>
				</div>
			</div>
		</div>
	</div>	
</header>

<?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/includes/header.blade.php ENDPATH**/ ?>