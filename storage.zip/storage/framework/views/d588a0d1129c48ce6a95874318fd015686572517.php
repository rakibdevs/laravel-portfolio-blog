

<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('class', 'home'); ?>

<?php $__env->startSection('banner'); ?>
<?php $__env->startPush('css'); ?>
    <meta property="og:image" content="<?php echo e(asset('images/rakib-cartoonized.jpg')); ?>">
<?php $__env->stopPush(); ?>
    <section class="banner">
        <div class="row m-0">
            <div class="col-sm-6 author-photo">
                <img src="<?php echo e(asset('images/rakib-cartoonized.jpg')); ?>">
            </div>
            <div class="col-sm-6 author-info">
                <span class="greetings">Hello I'm</span>
                <h2 class="name"><b>MD. RAKIBUL ISLAM</b></h2>
                <div class="author-tags">
                    
                    <div id="text-1">Expert in </div> 
                    <div id="text-2"> 
                      <span id="text-2-span"><span style="color:#f55247;">Laravel</span></span>
                    </div>
                </div>
                <div class="space-10"></div>
                <h1 class="author-slogan">
                    I want to 
                    <span class="slogan-highlight theme-background">make things</span><br>
                    that <u class="slogan-underline">make a difference</u>.
                </h1>

                <a href="" class="mt-20 btn-theme hvr-hang">LET'S TALK</a>

        
                
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="row">
            <div class="col-sm-6">
                <h3>WHAT I DO</h3>
                <ul class="what-i-do">
                    <li><i class="fa fa-clone" aria-hidden="true"></i> Analyze data and processes</li>
                    <li><i class="fa fa-clone" aria-hidden="true"></i> Develop ideas for new programs, products or features</li>
                    <li><i class="fa fa-clone" aria-hidden="true"></i> Develop front end website architecture</li>
                    <li><i class="fa fa-clone" aria-hidden="true"></i> Develop RESTful web services and APIs</li>
                </ul>
            </div>
            <div class="col-sm-6">            
                <div class="cubespinner">
                    <div class="face face1">
                        Laravel<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                90%
                            </div>
                        </div>
                    </div>
                    <div class="face face2">
                        Vue.js<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                60%
                            </div>
                        </div>
                    </div>
                    <div class="face face3">
                        Javascript<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                70%
                            </div>
                        </div>
                    </div>
                    <div class="face face4">
                        PHP<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                80%
                            </div>
                        </div>
                    </div>
                    <div class="face face5">
                        MySql<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                70%
                            </div>
                        </div>
                    </div>
                    <div class="face face6">
                        Wordpress<br>
                        <div class="progress">
                            <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
                                70%
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    

    <section class="project">
        <div class="row">
            <div class="col-sm-12">
                <h3 class="center">LETS HAVE A LOOK</h3>
                <hr>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class=" section-content ">
                    
                    <h4>RADMIN - LARAVEL ADMIN STARTER</h4>
                    <p class="">Laravel admin panel with REST API, Advanced user, roles & permission management , Serverside Datatable, Datatable Edit and Export,Cache Clear, XSS protection...</p>
                    <div class="section-buttons">
                        <a href="http://radmin.rakibhstu.com/" class="btn-theme hvr-hang">VIEW DEMO</a>
                        <a href="https://codecanyon.net/item/laravel-admin-template-roles-permission-editable-datatables/26005211" class="btn-theme hvr-hang" style="background-color: rgb(230, 59, 25);">BUY NOW</a>
                    </div>
                </div>
                <div class="section-image ">
                    <a href="">
                        <img src="<?php echo e(asset('images/projects/banner.jpg')); ?>">
                    </a>
                    <div class="feature-url">
                        <img alt="Laravel Admin Starter Kit" src="https://img.shields.io/badge/Laravel-Admin Starter Kit-red">
                        <img alt="Codecanyon Item Sale 64" src="https://img.shields.io/badge/Codecanyon Sale-64-red">
                    </div>
                </div>
                
            </div>

            <div class="col-sm-6">
                <div class="section-content">
                    <h4>NUMBER TO BANGLA</h4>
                    <p class="">Laravel package to convert English numbers to Bangla number or Bangla text, Bangla month name and Bangla Money Format for LARAVEL > 5.5. Just run </p>
                    <div class="section-buttons">
                        <a href="<?php echo e(url('docs/number-to-bangla')); ?>" class="btn-theme hvr-hang">DOCUMENTATION</a>
                    </div>
                    
            </div>
                <div class="section-image">
                    <div class="code-view">
                        <span class="code-text">>_ bnWord(1234.678)</span>
                        <span class="code-output">এক হাজার দুই শত চৌত্রিশ দশমিক ছয় সাত আট</span>
                        <span class="code-text">>_ bnNum(1234.098)</span>
                        <span class="code-output">১২৩৪.০৯৮</span>
                        <span class="code-text">>_ bnMoney(1234.35)</span>
                        <span class="code-output">এক হাজার দুই শত চৌত্রিশ টাকা পঁয়ত্রিশ পয়সা</span>
                        <span class="code-text">>_ bnMonth(4)</span>
                        <span class="code-output">এপ্রিল</span>
                    </div>
                    <div class="feature-url">
                        <img alt="Laravel Package" src="https://img.shields.io/badge/Laravel-Package-red">
                        <img alt="Packagist" src="https://img.shields.io/packagist/dt/rakibhstu/number-to-bangla">
                    </div>
                </div>
            </div> 
            
        </div>
    </section>

     <section class="portfolio">
        <project-component :categories = "<?php echo e($categories); ?>"></project-component>
    </section>


    <?php $__env->startPush('script'); ?>
        <script>
            var text2 = [
                            "<span style='color:#42b883;'>Vue.js</span>",
                            "<span style='color:#21759b;'>Wordpress</span>",
                            "<span style='color:#00758f;'>My</span><span style='color:#f29111;'>Sql</span>", 
                            "<span style='color:#f55247;'>Laravel</span>"
                        ];
            var count = 0;
            setInterval(() => {
                document.getElementById('text-2-span').innerHTML= text2[count];
                count++;
                if(count == 4){
                    count = 0;
                }
            }, 7000);

        </script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rakibhstu/public_html/resources/views/index.blade.php ENDPATH**/ ?>