<?php
	$segment = request()->segment(1);
?>
<header>
	<div class="main-container">		
		<span class="mobile-humberger" onclick="openNav()">&#9776;</span>
		<div id="main-menu" class="main-menu">
			<span href="javascript:void(0)" class="menu-close" onclick="closeNav()">&times;</span>
			<li class="author-logo">
				<a href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('images/logo.png')); ?>"></a>
			</li>
			<li >
				<a class="<?php echo e(($segment == 'portfolio') ? 'active' : ''); ?>" href="<?php echo e(url('portfolio')); ?>" alt="PORTFOLIO">PORTFOLIO</a></li>
			<li >
				<a class="<?php echo e(($segment == 'media') ? 'active' : ''); ?>" href="<?php echo e(url('media/rakibulislam_resume.pdf')); ?>" alt="RESUME">RESUME</a></li>
			<li>
				<a class="<?php echo e(($segment == 'blog') ? 'active' : ''); ?>" alt="BLOG">BLOG</a>
			</li>
		</div>
	</div>	
</header>

<?php /**PATH D:\Documents\Archives\rakibul.dev\resources\views/includes/header.blade.php ENDPATH**/ ?>