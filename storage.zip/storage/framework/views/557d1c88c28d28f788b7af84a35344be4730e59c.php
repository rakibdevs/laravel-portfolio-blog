

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
	hi
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/rakibhstu/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>