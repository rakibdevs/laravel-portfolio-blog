

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <portfolio-form :categories = "<?php echo e($categories); ?>" :technologies = "<?php echo e($technologies); ?>"></portfolio-form>                   
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/admin/portfolio-add.blade.php ENDPATH**/ ?>