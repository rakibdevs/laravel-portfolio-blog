<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<title> <?php echo $__env->yieldContent('title'); ?> | Rakibul Islam - Laravel and Vue.js Developer-</title>
	<meta name="description" content="Md. Rakibul Islam is a passoinate Laravel and Vue.js developer. He has also experiences in core PHP, Javascript, jQuery, Mysql and wordpress.">
	<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="<?php echo $__env->yieldContent('class'); ?>">
	<div id="app">

		<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->yieldContent('banner'); ?>

		<div class="main-container">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<?php echo $__env->yieldPushContent('script'); ?>
</body>
</html><?php /**PATH D:\Documents\Archives\rakibul.dev\resources\views/layouts/page.blade.php ENDPATH**/ ?>