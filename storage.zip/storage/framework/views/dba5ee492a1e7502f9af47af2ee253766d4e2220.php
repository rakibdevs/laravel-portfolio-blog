<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <title>Rakibul Islam | Admin- <?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('admin.includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('css'); ?>

</head>
<body>
    <div id="app">
        <div class="wrapper">
            <?php echo $__env->make('admin.includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="page-wrap">
                <!-- initiate sidebar-->
                <?php echo $__env->make('admin.includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="main-content">
                    <!-- yeild contents here -->
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- initiate scripts-->
    <?php echo $__env->make('admin.includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('script'); ?>

</body>
</html><?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/admin/layouts/main.blade.php ENDPATH**/ ?>