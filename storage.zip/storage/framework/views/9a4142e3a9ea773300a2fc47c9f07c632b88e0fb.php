

<?php $__env->startSection('title', 'Portfolios'); ?>
<?php $__env->startPush('css'); ?>
<?php $__env->startSection('content'); ?>
<div class="space-10"></div>
<portfolio-component :categories = "<?php echo e($categories); ?>"></portfolio-component >
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\personal-portfolio-with-blog\resources\views/portfolio.blade.php ENDPATH**/ ?>