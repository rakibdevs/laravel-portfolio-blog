@extends('admin.layouts.main')

@section('content')
<div class="container-fluid">
	hi
</div>
@endsection 